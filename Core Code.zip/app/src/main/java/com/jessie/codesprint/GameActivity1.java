package com.jessie.codesprint;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Jessie on 5/6/2016.
 */
public class GameActivity1 extends Activity implements View.OnClickListener{

    ArrayList<String> inputList = new ArrayList<String>(9);
    Button temp;
    int player1count = 0;
    int player2count = 0;
    //Player 1 is true
    //Player 2 is false
    boolean player = true;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.board);
        View resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(this);
        View one = findViewById(R.id.one);
        one.setOnClickListener(this);
        View two = findViewById(R.id.two);
        two.setOnClickListener(this);
        View three = findViewById(R.id.three);
        three.setOnClickListener(this);
        View four = findViewById(R.id.four);
        four.setOnClickListener(this);
        View five = findViewById(R.id.five);
        five.setOnClickListener(this);
        View six = findViewById(R.id.six);
        six.setOnClickListener(this);
        View seven = findViewById(R.id.seven);
        seven.setOnClickListener(this);
        View eight = findViewById(R.id.eight);
        eight.setOnClickListener(this);
        View nine = findViewById(R.id.nine);
        nine.setOnClickListener(this);



        inputList.add(0, "1");
        inputList.add(1,"2");
        inputList.add(2,"3");
        inputList.add(3,"4");
        inputList.add(4,"5");
        inputList.add(5,"6");
        inputList.add(6,"7");
        inputList.add(7,"8");
        inputList.add(8,"9");

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.resetButton){
            Intent myintent = new Intent(this, MainActivity.class);
            startActivity(myintent);
            Log.d("Test1", "1");
        }
        if(v.getId() == R.id.one){
            Button temp = (Button) findViewById(R.id.one);
            converter(temp);
            Log.d("Test2", "2");
        }
        if(v.getId() == R.id.two){
            Button temp = (Button) findViewById(R.id.two);
            converter(temp);
            Log.d("Test3", "3");
        }
        if(v.getId() == R.id.three){
            Button temp = (Button) findViewById(R.id.three);
            converter(temp);
            Log.d("Test4", "4");
        }
        if(v.getId() == R.id.four){
            Button temp = (Button) findViewById(R.id.four);
            converter(temp);
            Log.d("Test5", "5");
        }
        if(v.getId() == R.id.five){
            Button temp = (Button) findViewById(R.id.five);
            converter(temp);
            Log.d("Test6", "6");
        }
        if(v.getId() == R.id.six)
        {
            Button temp = (Button) findViewById(R.id.six);
            converter(temp);
            Log.d("Test7", "7");
        }
        if(v.getId() == R.id.seven)
        {
            Button temp = (Button) findViewById(R.id.seven);
            converter(temp);
            Log.d("Test8", "8");
        }
        if(v.getId() == R.id.eight)
        {
            Button temp = (Button) findViewById(R.id.eight);
            converter(temp);
            Log.d("Test9", "9");
        }
        if(v.getId() == R.id.nine)
        {
            Button temp = (Button) findViewById(R.id.nine);
            converter(temp);
            Log.d("Test10", "10");
        }
        TextView text;
        if(whoTurn() == true){
            text = (TextView) findViewById(R.id.whoTurn);
            text.setText("Player 1's Turn");
            win();
            Log.d("Test11", "11");
        }
        else{
            text = (TextView) findViewById(R.id.whoTurn);
            text.setText("Player 2's Turn");
            win();
            Log.d("Test12", "12");
        }
    }

    public void checkAdd(int spot){

        if(inputList.isEmpty()){
            //Add part
            if(whoTurn() == true){
                inputList.add(spot - 1, "p1");
                inputList.remove(spot);
                changeColor(spot);
                Log.d("Test13", "13");
                return;
            }
            Log.d("Test14", "14");
            inputList.add(spot - 1, "p2");
            inputList.remove(spot);
            changeColor(spot);
        }
        else if(inputList.get(spot-1).equals("p1") || inputList.get(spot-1).equals("p2")){
            //Returns true if the element is in there
            //Do nothing??
            //toast player 2 wins

            Log.d("Test15", "15");
            Context context = getApplicationContext();
            Toast.makeText(context,"You can't move here", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            //Add part
            if(whoTurn() == true){
                Log.d("Test16", "16");
                inputList.add(spot - 1, "p1");
                inputList.remove(spot);
                changeColor(spot);
                return;
            }
            Log.d("Test17", "17");
            inputList.add(spot-1, "p2");
            inputList.remove(spot);
            changeColor(spot);
        }
        Log.d("Test18", "18");
        return;
    }
    public void changeColor(int num){
        //Someone has won
        if(win() == true){
            if(whoTurn() == false){
                final Button test = reverse(num);
                Log.d("Test19", "19");
                test.setBackgroundColor(Color.YELLOW);
                return;

            }
            //Player 1 just went
            if(whoTurn() == true){
                final Button test2 = reverse(num);
                test2.setBackgroundColor(Color.RED);
            }

            return;
        }
        //Player 2 just went
        if(whoTurn() == false){
            final Button test = reverse(num);
            test.setBackgroundColor(Color.YELLOW);
            player = true;
            return;

        }
        //Player 1 just went
        if(whoTurn() == true){
            final Button test2 = reverse(num);
            test2.setBackgroundColor(Color.RED);
            player = false;
        }
    }
    public boolean win(){
       // inputList.add(0);
        /* for(int i=0; i < inputList.size() - 1; i++)
         {
             for(int j=2; j<inputList.size(); j++) {

                 for(int k=4; k<inputList.size();k++)
                 {


                 }
             }

         }*/
        if(inputList.get(0).equals("p1") && inputList.get(4).equals("p1") && inputList.get(8).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "!!!!!Player 1 Wins!!!!", Toast.LENGTH_SHORT).show();
            disableButtons();

            return true;

        }
        if(inputList.get(0).equals("p1") && inputList.get(3).equals("p1") && inputList.get(6).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 1 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;

        }
        if(inputList.get(0).equals("p1") && inputList.get(1).equals("p1") && inputList.get(2).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 1 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(1).equals("p1") && inputList.get(4).equals("p1") && inputList.get(7).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 1 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(5).equals("p1") && inputList.get(4).equals("p1") && inputList.get(3).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 1 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(8).equals("p1") && inputList.get(7).equals("p1") && inputList.get(6).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 1 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(2).equals("p1") && inputList.get(5).equals("p1") && inputList.get(8).equals("p1"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "!!!!!Player 1 Wins!!!!", Toast.LENGTH_SHORT).show();
            disableButtons();

            return true;

        }
        //PLAYER 2 STUFFFF
        if(inputList.get(0).equals("p2") && inputList.get(4).equals("p2") && inputList.get(8).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;

        }
        if(inputList.get(0).equals("p2") && inputList.get(3).equals("p2") && inputList.get(6).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;

        }
        if(inputList.get(0).equals("p2") && inputList.get(1).equals("p2") && inputList.get(2).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(1).equals("p2") && inputList.get(4).equals("p2") && inputList.get(7).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(5).equals("p2") && inputList.get(4).equals("p2") && inputList.get(3).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(8).equals("p2") && inputList.get(7).equals("p2") && inputList.get(6).equals("p2"))
        {
            //toast player 2 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "Player 2 Wins", Toast.LENGTH_SHORT).show();
            disableButtons();
            return true;
        }
        if(inputList.get(2).equals("p2") && inputList.get(5).equals("p2") && inputList.get(8).equals("p2"))
        {
            //toast player 1 wins
            Context context = getApplicationContext();
            Toast.makeText(context, "!!!!!Player 1 Wins!!!!", Toast.LENGTH_SHORT).show();
            disableButtons();

            return true;

        }

        return false;
    }
    public boolean whoTurn(){
        if(player == true){
            Log.d("Test21", "21");
            return true;
        }
        Log.d("Test22", "22");
        return false;
    }
    public Button reverse (int num){
        Button temp = (Button) findViewById(R.id.resetButton);;
        if(num == 1){
            temp = (Button) findViewById(R.id.one);
        }
        if(num == 2){
            temp = (Button) findViewById(R.id.two);
        }
        if(num == 3){
            temp = (Button) findViewById(R.id.three);
        }
        if(num == 4){
            temp = (Button) findViewById(R.id.four);
        }
        if(num == 5){
            temp = (Button) findViewById(R.id.five);
        }
        if(num == 6){
            temp = (Button) findViewById(R.id.six);
        }
        if(num == 7){
            temp = (Button) findViewById(R.id.seven);
        }
        if(num == 8){
            temp = (Button) findViewById(R.id.eight);
        }
        if(num == 9){
            temp = (Button) findViewById(R.id.nine);
        }
        return  temp;
    }
    public int converter(Button pressed)
    {
        int num = 0;

        if(pressed == (Button) findViewById(R.id.one))
        {
            num = 1;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.two))
        {
            num = 2;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.three))
        {
            num = 3;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.four))
        {
            num = 4;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.five))
        {
            num = 5;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.six))
        {
            num = 6;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.seven))
        {
            num = 7;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.eight))
        {
            num = 8;
            checkAdd(num);
        }
        if(pressed == (Button) findViewById(R.id.nine))
        {
            num = 9;
            checkAdd(num);
        }
        return num;
    }

    public void disableButtons()
    {
        findViewById(R.id.one).setEnabled(false);
        findViewById(R.id.two).setEnabled(false);
        findViewById(R.id.three).setEnabled(false);
        findViewById(R.id.four).setEnabled(false);
        findViewById(R.id.five).setEnabled(false);
        findViewById(R.id.six).setEnabled(false);
        findViewById(R.id.seven).setEnabled(false);
        findViewById(R.id.eight).setEnabled(false);
        findViewById(R.id.nine).setEnabled(false);

    }
}
